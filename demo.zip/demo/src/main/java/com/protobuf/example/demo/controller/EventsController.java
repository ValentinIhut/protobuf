package com.protobuf.example.demo.controller;

import com.protobuf.example.demo.dto.EventDto;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author valentin.ihut
 * @since 1.0.0
 */
@RestController
public class EventsController {

  @PostMapping(value = "/events")
  public ResponseEntity<EventDto> postEvent(@RequestBody EventDto eventDto) {
    return ResponseEntity.noContent().build();
  }

}
