package com.protobuf.example.demo.service.impl;

import com.protobuf.example.demo.dto.EventDto;
import com.protobuf.example.demo.exception.BusinessException;
import com.protobuf.example.demo.proto.EventsProto.Event;
import com.protobuf.example.demo.service.NotificationService;
import com.protobuf.example.demo.utils.DtoToProtoConverter;
import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * @author valentin.ihut
 * @since 1.0.0
 */
@Service
public class NotificationServiceImpl implements NotificationService {

  @Value("${socket.ip}")
  private String socketIp;

  @Value("${socket.port}")
  private Integer socketPort;

  @Override
  public synchronized void sendSocketMessageToServer(EventDto eventDto) throws BusinessException {
    Event protoEvent = DtoToProtoConverter.convertDtoToProto(eventDto);
    sendSocketMessage(protoEvent);
  }

  private String sendSocketMessage(Event event) throws BusinessException {
    try (SocketChannel channel = SocketChannel.open(new InetSocketAddress(InetAddress.getByName(socketIp), socketPort))) {

      //write data to socket server
      ByteBuffer byteBuffer = ByteBuffer.allocate(1024);
      byteBuffer.put(event.toByteArray());
      byteBuffer.flip();
      channel.write(byteBuffer);

      //read data from socket server
      ByteBuffer buf = ByteBuffer.allocate(1024);
      int numBytesRead = channel.read(buf);
      if (numBytesRead == -1) {
        channel.close();
      }
      return buf.toString();
    } catch (IOException e) {
      throw new BusinessException(e.getMessage());
    }
  }

}
